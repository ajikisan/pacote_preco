from valor_preco import preco, dado
